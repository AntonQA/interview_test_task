let ssls_HomePageObject = function () {

  let EC = protractor.ExpectedConditions;

  this.homePage_logo = element(by.css('[class="logo"]'));


  this.viewProfile_button = element(by.css('[href="/user/profile"]'));
  this.triangle_button = element(by.css('.dropdown-btn'));



  this.personal_Filter_button = element(by.xpath('//*[contains(@class, "filter-item")]/*[contains(text(), "Personal")]'));
  // this.personal_Filter_button_active = element(by.cssContainingText('[class="btn block round control active"]', 'Personal'));
  this.multiDomain_Filter_button = element(by.xpath('//*[contains(@class, "filter-item")]/*[contains(text(), "multi-domain")]'));
  this.sorting_button = element(by.xpath('//*[@id="certs"]//*[contains(@class, "round control ng-scope")]'));
  //*[@id="certs"]//*[contains(@class, "icon-sort")]
  this.ecomemrce_Filter_button = element(by.xpath('//*[@class="filter-item"]/*[contains(text(), "Ecommerce")]'));
  this.business_Filter_button = element(by.xpath('//*[@class="filter-item"]/*[contains(text(), "Business")]'));

  this.ssl_price = element(by.xpath('//div[@class="ssl-price-box"]/price[contains(@class, "lg-price")]'));

  var nameOfElements_list = element.all(by.css('.ssl-name'));
  var contentOfElements_list = element.all(by.css('.ssl-content'));




  /* these functions take all the filtered elements 
  and check that ONLY expected ssl certificates are displayed after applying “Personal” filter */

  this.check_Personal_filter_applied = async function () {

    await expect(nameOfElements_list.count()).toBe(5);

    await contentOfElements_list.each(async function (element, index) {
      await expect(element.getCssValue('background-color')).toEqual("rgba(154, 220, 237, 1)");
    });

    await nameOfElements_list.then(async function (elements) {
      await expect(elements[0].getText()).toContain('PositiveSSL');
      await expect(elements[1].getText()).toContain('EssentialSSL');
      await expect(elements[2].getText()).toContain('PositiveSSL Wildcard');
      await expect(elements[3].getText()).toContain('PositiveSSL Multi-Domain');
      await expect(elements[4].getText()).toContain('EssentialSSL Wildcard');
    });

  };



  this.check_Personal_and_MultiDomain_filter_applied = async function () {

    await expect(nameOfElements_list.count()).toBe(1);

    await contentOfElements_list.each(async function (element, index) {
        await expect(element.getText()).toContain('www.site.com or site.com');         // check each SSL cert to be "Multi-Domain" by 'www.site.com or site.com' text
    });

    await nameOfElements_list.then(async function (elements) {
        await expect(elements[0].getText()).toContain('PositiveSSL Multi-Domain');
    });
    
  };





  this.check_Featured_filter_applied = async function () {

    await expect(nameOfElements_list.count()).toBe(13);

    await nameOfElements_list.then(async function (elements) {
      await expect(elements[0].getText()).toContain('PositiveSSL');
      await expect(elements[1].getText()).toContain('EssentialSSL');
      await expect(elements[2].getText()).toContain('EV SSL');
      await expect(elements[3].getText()).toContain('PositiveSSL Wildcard');
      await expect(elements[4].getText()).toContain('PositiveSSL Multi-Domain');
      await expect(elements[5].getText()).toContain('InstantSSL');
      await expect(elements[6].getText()).toContain('EssentialSSL Wildcard');
      await expect(elements[7].getText()).toContain('InstantSSL Pro');
      await expect(elements[8].getText()).toContain('EV Multi-Domain SSL');
      await expect(elements[9].getText()).toContain('PremiumSSL');
      await expect(elements[10].getText()).toContain('Unified Communications');
      await expect(elements[11].getText()).toContain('PremiumSSL Wildcard');
      await expect(elements[12].getText()).toContain('Multi-Domain SSL');
    });
  
  };




  this.check_Cheapest_filter_applied = async function () {

    await expect(nameOfElements_list.count()).toBe(13);

    // here we check sorting order by the price - cheapest on the top
    await element.all(by.xpath('//div[@class="ssl-price-box"]/price[contains(@class, "lg-price")]')).then(async function (elements) {

      let price1 = + await elements[0].getAttribute('value');
      let price2 = + await elements[1].getAttribute('value');
      let price3 = + await elements[2].getAttribute('value');
      let price4 = + await elements[3].getAttribute('value');
      let price5 = + await elements[4].getAttribute('value');
      let price6 = + await elements[5].getAttribute('value');
      let price7 = + await elements[6].getAttribute('value');
      let price8 = + await elements[7].getAttribute('value');
      let price9 = + await elements[8].getAttribute('value');
      let price10 = + await elements[9].getAttribute('value');
      let price11 = + await elements[10].getAttribute('value');
      let price12 = + await elements[11].getAttribute('value');
      let price13 = + await elements[12].getAttribute('value');

      expect(price1 <= price2).toBe(true);
      expect(price2 <= price3).toBe(true);
      expect(price3 <= price4).toBe(true);
      expect(price4 <= price5).toBe(true);
      expect(price4 <= price5).toBe(true);
      expect(price5 <= price6).toBe(true);
      expect(price6 <= price7).toBe(true);
      expect(price7 <= price8).toBe(true);
      expect(price8 <= price9).toBe(true);
      expect(price9 <= price10).toBe(true);
      expect(price10 <= price11).toBe(true);
      expect(price11 <= price12).toBe(true);
      expect(price12 <= price13).toBe(true);

    });
    // here we compare elements by SSL name (title) - checking that their positions are not changed
    await nameOfElements_list.then(async function (elements) {
      await expect(elements[0].getText()).toContain('PositiveSSL');
      await expect(elements[1].getText()).toContain('EssentialSSL');
      await expect(elements[2].getText()).toContain('InstantSSL');
      await expect(elements[3].getText()).toContain('PositiveSSL Multi-Domain');
      await expect(elements[4].getText()).toContain('InstantSSL Pro');
      await expect(elements[5].getText()).toContain('PremiumSSL');
      await expect(elements[6].getText()).toContain('EssentialSSL Wildcard');
      await expect(elements[7].getText()).toContain('PositiveSSL Wildcard');
      await expect(elements[8].getText()).toContain('EV SSL');
      await expect(elements[9].getText()).toContain('Multi-Domain SSL');
      await expect(elements[10].getText()).toContain('Unified Communications');
      await expect(elements[11].getText()).toContain('PremiumSSL Wildcard');
      await expect(elements[12].getText()).toContain('EV Multi-Domain SSL');
    });

  };








};
module.exports = new ssls_HomePageObject();




