let ssls_ProfilePageObject = function() {

    let EC = protractor.ExpectedConditions;

	this.homePage_logo  = element(by.css('[class="logo"]'));

   
  this.viewProfile_button = element(by.css('[href="/user/profile"]'));
  this.triangle_button = element(by.css('.dropdown-btn'));

  

  this.name_label = element(by.cssContainingText('[class="text"]', 'Name'));
  //this.name_label = element(by.xpath('//span[text()="Name"]'));
  this.name_text = element(by.xpath('//span[text()="Name"]/ancestor::div[2]/*[@class="description"]'));
  

  this.email_label = element(by.cssContainingText('[class="text"]', 'Email'));
  //this.email_label = element(by.xpath('//span[text()="Email"]'));
  this.email_text = element(by.xpath('//span[text()="Email"]/ancestor::div[2]/*[@class="description"]'));

  this.password_label = element(by.cssContainingText('[class="text"]', 'Password'));
  //this.password_label = element(by.xpath('//span[text()="Password"]'));
  this.password_text = element(by.xpath('//span[text()="Password"]/ancestor::div[2]/*[@class="description"]'));

  this.phone_label = element(by.cssContainingText('[class="text"]', 'Phone'));
  //this.phone_label = element(by.xpath('//span[text()="Phone"]'));
  this.phone_text = element(by.xpath('//span[text()="Phone"]/ancestor::div[2]/*[@class="description"]'));

  this.address_label = element(by.cssContainingText('[class="text"]', 'Address'));
  //this.address_label = element(by.xpath('//span[text()="Address"]'));
  this.address_text = element(by.xpath('//span[text()="Address"]/ancestor::div[2]/*[@class="description"]'));

  this.supportPin_label = element(by.cssContainingText('[class="text"]', 'Support pin'));
  //this.supportPin_label = element(by.xpath('//span[text()="Support pin"]'));
  this.supportPin_text = element(by.xpath('//span[text()="Support pin"]/ancestor::div[2]/*[@class="description"]'));
  this.supportPin_button = element(by.css('[name="supportPin"]'));

  this.newsletter_label = element(by.cssContainingText('[class="text"]', 'Newsletter'));
  //this.newsletter_label = element(by.xpath('//span[text()="Newsletter"]'));
  this.newsletter_Toggle_Btn_On = element(by.xpath('//span[text()="Newsletter"]/ancestor::div[2]//*[@class="toggle-btn on"]'));
  this.newsletter_Toggle_Btn_Off = element(by.xpath('//span[text()="Newsletter"]/ancestor::div[2]//*[@class="toggle-btn"]'));

  this.goTo_ViewProfile = async function () {
		await this.triangle_button.click();
		await browser.wait(EC.elementToBeClickable(this.viewProfile_button), 10000);	// Waits for the element to be present on the dom and clickable.
    await this.viewProfile_button.click();
    await browser.wait(EC.urlContains('/user/profile'), 5000);				 			  
  };
  
  
  this.Save_Profile_fieldValues = async function () {
    this.nameText_saved = await this.name_text.getText();
    this.emailText_saved = await this.email_text.getText();
    this.phoneText_saved = await this.phone_text.getText();
    this.addressText_saved = await this.address_text.getText();
    this.supportPinText_saved = await this.supportPin_text.getText();
    this.newsletterText_saved = await this.newsletter_Toggle_Btn_On.isPresent();		 			  
	};


  
	


	
};
module.exports = new ssls_ProfilePageObject();

	
	
	
	