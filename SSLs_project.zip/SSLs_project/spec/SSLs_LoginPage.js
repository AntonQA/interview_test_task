let ssls_LoginPageObject = function() {

    let EC = protractor.ExpectedConditions;

	this.homePage_logo  = element(by.css('[class="logo"]'));

    this.log_in_topText  = element(by.css('.log-box'));
	this.login_button = element(by.cssContainingText('[class="btn block primary"]', 'Login'));
	this.logOut_button = element(by.xpath('//button[text()="Log out"]'));

	this.email_input = element(by.css('[placeholder="Email"]'));
    this.password_input = element(by.css('[name="password"]'));
    this.crossedEye_icon = element(by.css('.icon-eye-off'));
	this.openedEye_icon = element(by.css('.icon-eye'));
	this.password_input_textMode = element(by.xpath('//input[@name="password" and @type="text"]'));

	this.errorMessage = element(by.css('.noty_text'));
	this.invalidEmail_errorMessage = element(by.xpath('//input[@placeholder="Email"]/following-sibling::div[1]//*[@class="tooltip-text"]'));
	this.emptyEmail_errorMessage = element(by.xpath('//input[@placeholder="Email"]/following-sibling::div[2]//*[@class="tooltip-text"]'));
	this.emptyPassword_errorMessage = element(by.xpath('//*[@class="input-group"]/following-sibling::div[1]//*[@class="tooltip-text"]'));
	
    
    this.triangle_button = element(by.css('.dropdown-btn'));
	this.profileBox = element(by.css('.profile-box'));
	this.userButton = element(by.css('.user-btn'));

	

	

	// Login scenario OBJECT

	this.LogIn = async function (user, pass, url) {	
		await browser.get(url);
		await browser.wait(EC.visibilityOf(this.log_in_topText), 8000);
        await this.log_in_topText.click();
		await browser.wait(EC.elementToBeClickable(this.login_button), 5000);
		await this.email_input.clear();
		await this.email_input.sendKeys(user);
		await this.password_input.clear();
		await this.password_input.sendKeys(pass);
		await this.login_button.click();
		};
	
		
        
    // Logout scenario OBJECTs
    
	this.Logout = async function () {

		await this.profileBox.isPresent().then( async(result) => {  
			if (result) {
				await this.LogoutFrom();			 			
	            } else {  
                   await this.LogIn('ssls.automation+5@gmail.com', '123456', 'https://ssls.com');
                   await browser.wait(EC.visibilityOf(this.profileBox), 8000);
                   await this.LogoutFrom();	
                 }
		});
	};

	this.LogoutFrom = async function () {
		await this.triangle_button.click();
		await browser.wait(EC.elementToBeClickable(this.logOut_button), 10000);	// Waits for the element to be present on the dom and clickable.
		await this.logOut_button.click();				 			  
	};
	

	
    
    




	
};
module.exports = new ssls_LoginPageObject();

	
	
	
	