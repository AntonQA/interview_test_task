describe('Authorization page. Not registered user', function() {

	let loginPage = require('../spec/SSLs_LoginPage.js');
	
	 let EC = protractor.ExpectedConditions;
     browser.driver.manage().window().maximize();
     let url = 'https://ssls.com';
     let email = 'qatest@gmail.com';
     let pass = '123456';
     

     it('Check that user is NOT logged in', async function() {
        await browser.get(url);
        await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

        await loginPage.profileBox.isPresent().then( async(result) => { 
			  if (result) { 
          await loginPage.LogoutFrom();	
          await browser.wait(EC.urlIs('https://www.ssls.com/authorize'), 5000);		 			
	                  } else {   /*do nothjing */  }
		    });
        
    });
     

     
     it('Log in to app with not registered email and any password ', async function() {

        await loginPage.LogIn(email, pass, url);
        await browser.wait(EC.visibilityOf(loginPage.errorMessage), 5000);
        await  expect(loginPage.errorMessage.getText()).toEqual('Uh oh! Email or password is incorrect');
        //await browser.sleep(2000);
        
     });
     
     



});