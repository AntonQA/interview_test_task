describe('My profile page. Refresh support pin', function() {

    let loginPage = require('../spec/SSLs_LoginPage.js');
	let profilePage = require('../spec/SSLs_ProfilePage.js');
	
	 let EC = protractor.ExpectedConditions;
     browser.driver.manage().window().maximize();
     let url = 'https://ssls.com';
     let email = 'ssls.automation+5@gmail.com';
     let pass = '123456';
     

     

     it('Check if User is logged in', async function() {

        await browser.get(url);
        await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

        await loginPage.profileBox.isPresent().then( async(result) => { 
			    if (result) {
				     /* do nothing */			 			
	        } else { 
                await loginPage.LogIn(email, pass, url);
                await browser.wait(EC.visibilityOf(loginPage.profileBox), 8000);
               await expect(loginPage.userButton.getText()).toContain(email); 
            }
	    });
        

     });




     it('Profile page: Refresh support pin', async function() {
 
        
        await profilePage.goTo_ViewProfile();  // navigate to View Profile page

        let supportPinText = await profilePage.supportPin_text.getText();
        await console.log(supportPinText);
    
        await profilePage.supportPin_button.click();

        await browser.wait(EC.not(EC.textToBePresentInElement(profilePage.supportPin_text, supportPinText), 8000), 8000);
        
        await expect(profilePage.supportPin_text.getText()).not.toEqual(supportPinText); 
        await console.log(await profilePage.supportPin_text.getText());
      
       // console.log has been added to verify Support Pin value difference (before and after click) visually as the script runs way too fast
     

     });
     
     



});