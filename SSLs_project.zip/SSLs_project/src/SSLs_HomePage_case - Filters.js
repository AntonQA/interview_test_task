describe('Home page. Filters', function () {

  let loginPage = require('../spec/SSLs_LoginPage.js');
  let homePage = require('../spec/SSLs_HomePage.js');

  let EC = protractor.ExpectedConditions;

  browser.driver.manage().window().maximize();
  let url = 'https://ssls.com';
  let email = 'ssls.automation+5@gmail.com';
  let pass = '123456';



  it('Check if User is logged in', async function () {

    await browser.get(url);
    await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

    await loginPage.profileBox.isPresent().then(async (result) => {
      if (result) {
        /* do nothing */
      } else {
        await loginPage.LogIn(email, pass, url);
        await browser.wait(EC.visibilityOf(loginPage.profileBox), 8000);
        await expect(loginPage.userButton.getText()).toContain(email);
      }
    });
  });



  it('Click on "Personal" filter button', async function () {
    await browser.wait(EC.elementToBeClickable(homePage.personal_Filter_button), 10000);
    await browser.executeScript('arguments[0].scrollIntoView()', homePage.personal_Filter_button.getWebElement());  // scroll-down to our element for visual control

    await homePage.personal_Filter_button.click();
    await expect(homePage.personal_Filter_button.getAttribute("class")).toContain("active");

    await homePage.check_Personal_filter_applied();

  });




  it('Click on "Personal" + "Multi-Domain" filter button', async function () {

    await browser.refresh();
    await browser.wait(EC.elementToBeClickable(homePage.personal_Filter_button), 10000);

    await browser.executeScript('arguments[0].scrollIntoView()', homePage.personal_Filter_button.getWebElement());  // scroll-down to our element for visual control

    //await expect(homePage.personal_Filter_button_active.isPresent()).toBe(true); 
    await homePage.personal_Filter_button.click();
    await homePage.multiDomain_Filter_button.click();
    await expect(homePage.multiDomain_Filter_button.getAttribute("class")).toContain("active");

    await browser.sleep(2000);
    await homePage.check_Personal_and_MultiDomain_filter_applied();

  });






  it('Verify SSL certs are sorted by “Featured” by default', async function () {

    await browser.refresh();
    await browser.wait(EC.elementToBeClickable(homePage.sorting_button), 10000);
    await browser.executeScript('arguments[0].scrollIntoView()', homePage.sorting_button.getWebElement());  // scroll-down to our element for visual control

    await expect(homePage.sorting_button.getText()).toContain('CHEAPEST');
    // here we do NOT click sorting button and verify that SSL certificates sorted by "Featured" by default
    await homePage.check_Featured_filter_applied();

  });

  it('Verify SSL certs are sorted by “Cheapest”', async function () {

    await browser.refresh();
    await browser.wait(EC.elementToBeClickable(homePage.sorting_button), 10000);
    await browser.executeScript('arguments[0].scrollIntoView()', homePage.sorting_button.getWebElement());  // scroll-down to our element for visual control

    await expect(homePage.sorting_button.getText()).toContain('CHEAPEST');
    await homePage.sorting_button.click();
    await expect(homePage.sorting_button.getText()).toContain('FEATURED');

    await homePage.check_Cheapest_filter_applied();

  });



 





});