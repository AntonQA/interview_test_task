describe('Authorization page. Empty fields', function() {

	let loginPage = require('../spec/SSLs_LoginPage.js');
	
	 let EC = protractor.ExpectedConditions;
     browser.driver.manage().window().maximize();
     let url = 'https://ssls.com';
     let email = '';
     let pass = '';
     

     it('Check that user is NOT logged in', async function() {
        await browser.get(url);
        await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

        await loginPage.profileBox.isPresent().then( async(result) => { 
			    if (result) {
				 await loginPage.LogoutFrom();			 			
	                        } else { /*do nothing */}
		});
        
    });
     

     
     it('Log in to app with empty Email and Password fields ', async function() {

        await loginPage.LogIn(email, pass, url);
        await browser.wait(EC.visibilityOf(loginPage.emptyEmail_errorMessage), 5000);
        await  expect(loginPage.emptyEmail_errorMessage.getText()).toBeTwinLike('Oops, please enter your email');
        await  expect(loginPage.emptyPassword_errorMessage.getText()).toBeTwinLike('Looks like you’ve missed this one');
        //await browser.sleep(2000);
        
     });
     
     



});