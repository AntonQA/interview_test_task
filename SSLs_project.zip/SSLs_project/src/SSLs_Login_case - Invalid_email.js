describe('Authorization page. Invalid email', function() {

	let loginPage = require('../spec/SSLs_LoginPage.js');
	
	 let EC = protractor.ExpectedConditions;
     browser.driver.manage().window().maximize();
     let url = 'https://ssls.com';
     let email = 'ssls.automation+5@@gmail.com';
     let pass = '123456';
     

     it('Check that user is NOT logged in', async function() {
        await browser.get(url);
        await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

        await loginPage.profileBox.isPresent().then( async(result) => { 
			    if (result) {
				     await loginPage.LogoutFrom();			 			
	        } else { /*do nothing */}
		    });
        
    });
     

     
     it('Log in to app with invalid email ', async function() {

        await loginPage.LogIn(email, pass, url);
        await browser.wait(EC.visibilityOf(loginPage.invalidEmail_errorMessage), 5000);
        await  expect(loginPage.invalidEmail_errorMessage.getText()).toBeTwinLike('Uh oh! This isn’t an email');
       
        
     });
     
     



});