
//     --------------------   SSLs Project ---------------

// Find detailed information on how to setup, run, and edit the Protractor setup at
// http://www.protractortest.org

// Information about Jasmine can be found here
// https://jasmine.github.io/1/3/introduction.html

// conf.js
let SpecReporter = require('jasmine-spec-reporter').SpecReporter;


exports.config = {
  framework: 'jasmine',
  //seleniumAddress: 'http://localhost:4444/wd/hub',
  //multiCapabilities: [{browserName: 'firefox'}, {browserName: 'chrome'}],
  //capabilities: {'browserName': 'firefox'},
  //capabilities: {'browserName': 'internet explorer'},
  capabilities: { 'browserName': 'chrome' },
 
  specs: ['SSLs_Login_case - Authorization_page.js', 'SSLs_Login_case - Not_registered_user.js', 'SSLs_Login_case - Invalid_email.js', 'SSLs_Login_case - Empty_fields.js', 'SSLs_Log Out.js', 'SSLs_MyProfile_case - Client_area.js', 'SSLs_MyProfile_case - Refresh_support_pin.js', 'SSLs_HomePage_case - Filters.js'],
  //specs: ['SSLs_Login_case - Authorization_page.js'],
  //specs: ['SSLs_Login_case - Not_registered_user.js'], 
  //specs: ['SSLs_Login_case - Invalid_email.js'],
  //specs: ['SSLs_Login_case - Empty_fields.js'],
  //specs: ['SSLs_Log Out.js'],
  //specs: ['SSLs_MyProfile_case - Client_area.js'],
  //specs: ['SSLs_MyProfile_case - Refresh_support_pin.js'],
  //specs: ['SSLs_HomePage_case - Filters.js'],
  directConnect: true,
  baseUrl: 'http://localhost:4200/',

  SELENIUM_PROMISE_MANAGER: false,

  jasmineNodeOpts: {
    defaultTimeoutInterval: 2500000,
  },


  onPrepare: function () {
    require('jasmine-expect');
    jasmine.getEnv().addReporter(new SpecReporter({
      displayStacktrace: 'specs',      // display stacktrace for each failed assertion, values: (all|specs|summary|none) 
      displaySuccessesSummary: false, // display summary of all successes after execution 
      displayFailuresSummary: true,   // display summary of all failures after execution 
      displayPendingSummary: true,    // display summary of all pending specs after execution 
      displaySuccessfulSpec: true,    // display each successful spec 
      displayFailedSpec: true,        // display each failed spec 
      displayPendingSpec: false,      // display each pending spec 
      displaySpecDuration: false,     // display each spec duration 
      displaySuiteNumber: false,      // display each suite number (hierarchical) 
      colors: {
        successful: 'green',
        failed: 'red',
        pending: 'yellow'
      },
      prefixes: {
        success: '✓ ',
        failure: '✗ ',
        pending: '* '
      },
      customProcessors: [],

    }));

	
    beforeEach(function () {
      jasmine.addMatchers({
        toBeTwinLike: function () {
          return {
            compare: function (actual, expected) {

              let result = {};

              let text = actual.replace(/\n/, ' ');

              result.pass = text === expected;

              if (result.pass) {
                console.log(` --- Correct error message or text is displayed ---  `);
              } else {
                console.log(` --- BUG!!!: Error message text is changed or User is logged in with invalid Credentials ---  `);
              }
              return result;

            }
          }
        }
      });
    });

  }

};