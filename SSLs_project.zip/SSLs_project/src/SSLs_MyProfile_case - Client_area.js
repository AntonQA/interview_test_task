describe('My profile page. Client area', function() {

    let loginPage = require('../spec/SSLs_LoginPage.js');
	let profilePage = require('../spec/SSLs_ProfilePage.js');
	
	 let EC = protractor.ExpectedConditions;
     browser.driver.manage().window().maximize();
     let url = 'https://ssls.com';
     let email = 'ssls.automation+5@gmail.com';
     let pass = '123456';
     

     

     it('Check if User is logged in', async function() {

        await browser.get(url);
        await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

        await loginPage.profileBox.isPresent().then( async(result) => { 
			    if (result) {
				     /* do nothing */			 			
	        } else { 
                await loginPage.LogIn(email, pass, url);
                await browser.wait(EC.visibilityOf(loginPage.profileBox), 8000);
                await expect(loginPage.userButton.getText()).toContain(email); 
            }
	    });
     });




     it('Profile page: Check fields have values and compare with ones from precondition', async function() {
 
        //Precondition block: Save values(Do not change saved values) of such fields in Profile - Name, Email, Phone, Address, Support Pin, Newsletter
        await profilePage.goTo_ViewProfile();
        await profilePage.Save_Profile_fieldValues();
        await loginPage.Logout();
        await browser.wait(EC.urlIs('https://www.ssls.com/authorize'), 5000);
        


        //Steps
        await loginPage.LogIn(email, pass, url);
        await browser.wait(EC.visibilityOf(loginPage.profileBox), 8000);

        await profilePage.goTo_ViewProfile();  // navigate to View Profile page
        
        await expect(profilePage.name_text.getText()).toEqual(profilePage.nameText_saved); 
        await expect(profilePage.email_text.getText()).toEqual(profilePage.emailText_saved); 
        await expect(profilePage.password_text.getText()).toContain("***");   // checking Password is not empty
        await expect(profilePage.phone_text.getText()).toEqual(profilePage.phoneText_saved); 
        await expect(profilePage.address_text.getText()).toEqual(profilePage.addressText_saved); 
        await expect(profilePage.supportPin_text.getText()).toEqual(profilePage.supportPinText_saved); 
        await expect(profilePage.newsletter_Toggle_Btn_On.isPresent()).toBe(true); 


     });
     
     



});