
describe('Log Out from the app', function() {

	let loginPage = require('../spec/SSLs_LoginPage.js');
	
	 let EC = protractor.ExpectedConditions;
     browser.driver.manage().window().maximize();
     
     
    
    it('Log Out from the app', async function() {

        await loginPage.Logout();
        
        await browser.wait(EC.visibilityOf(loginPage.login_button), 8000);
        await browser.wait(EC.urlIs('https://www.ssls.com/authorize'), 5000);
    
     });

     

});





