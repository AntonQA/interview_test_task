describe('Authorization page (Welcome back!)', function() {

	let loginPage = require('../spec/SSLs_LoginPage.js');
	
	 let EC = protractor.ExpectedConditions;
	 browser.ignoreSynchronization = true;
     browser.driver.manage().window().maximize();
     let url = 'https://ssls.com';
     let email = 'ssls.automation+5@gmail.com';
     let pass = '123456';



     it('Check that user is NOT logged in', async function() {
        await browser.get(url);
        await browser.wait(EC.visibilityOf(loginPage.homePage_logo), 8000);

        await loginPage.profileBox.isPresent().then( async(result) => { 
			  if (result) { 
          await loginPage.LogoutFrom();	
          await browser.wait(EC.urlIs('https://www.ssls.com/authorize'), 5000);		 			
	                  } else {   /*do nothjing */  }
		    });
        
    });
     

     it('Open Home page', async function() {

		await browser.get(url);
        await expect(browser.getCurrentUrl()).toBe('https://www.ssls.com/');
        
     });



     it('Click on LOG IN text at the right top nav', async function() {

        await browser.wait(EC.visibilityOf(loginPage.log_in_topText), 8000);
        await loginPage.log_in_topText.click();
        await browser.wait(EC.urlIs('https://www.ssls.com/authorize'), 5000);
        
     });



     it('Check entered password by clicking on "eye" icon for password field', async function() {

        await browser.wait(EC.visibilityOf(loginPage.password_input), 8000);
        await loginPage.password_input.sendKeys('123456');
        await expect(loginPage.password_input_textMode.isPresent()).toBe(false);
        await loginPage.openedEye_icon.click();
        await expect(loginPage.password_input_textMode.isPresent()).toBe(true);  // here we checking that after clikcing on 'eye' icon Password field attribute type="text"
        
     });


     
     it('Log in to the app', async function() {

        await loginPage.LogIn(email, pass, url);
        await browser.wait(EC.visibilityOf(loginPage.profileBox), 8000);
        await expect(loginPage.userButton.getText()).toContain(email); 

     });

     xit('Log Out from the app', async function() {

        await loginPage.Logout();
        await browser.wait(EC.visibilityOf(loginPage.login_button), 8000);
        await browser.wait(EC.urlIs('https://www.ssls.com/authorize'), 5000);
        await browser.sleep(4000);

     });
     
     



});